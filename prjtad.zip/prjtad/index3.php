<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Employés</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <a href="ajouter.php" class="Btn_add"> <img src="images/plus.png"> Ajouter</a>
        
        <table>
            <tr id="items">
                <th>NumAction</th>
                <th>NumProf</th>
                <th>DatePart</th>
                <th>Qualité</th>
                <th>Dpt</th>
                <th>Opt</th>
                <th>Niveau</th>
                <th>CodeMat</th>
                <th>Remarque</th>
                <th>Modifier</th>
                <th>Supprimer</th>
            </tr>
            <?php 
                include_once "connexion.php";
                $req = mysqli_query($con , " SELECT * FROM actionmember");
                 echo "Il n'y a pas encore d'actionMembres ajouter !" ;
                
                    while($row=mysqli_fetch_assoc($req)){
                        ?>
                        <tr>
                            <td><?=$row['NumAction']?></td>
                            <td><?=$row['NumProf']?></td>
                            <td><?=$row['DatePart']?></td>
                            <td><?=$row['Qualité']?></td>
                            <td><?=$row['Dpt']?></td>
                            <td><?=$row['Opt']?></td>
                            <td><?=$row['Niveau']?></td>
                            <td><?=$row['CodeMat']?></td>
                            <td><?=$row['Remarque']?></td>
                            <td><a href="modifier.php?id=<?=$row['NumAction']?>"><img src="images/pen.png"></a></td>
                            <td><a href="supprimer.php?id=<?=$row['NumAction']?>"><img src="images/trash.png"></a></td>
                        </tr>
                        <?php
                    }
            ?>
      
         
        </table>
   
   
   
   
    </div>
</body>
</html>