<?php
$host = "localhost";  
$user = 'dsi2g1';
$password ='dsi2g1';
$db='gestionscolaire';   

$conn = new mysqli($host, $user, $password, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
