<head>
  <meta charset="utf-8">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
      line-height: 1.6;
    }
    header {
      background-color: #f2f2f2;
      color: #f2f2f2;
      padding: 15px 0;
      text-align: center;
    }
    header a {
      color: #f2f2f2;
      text-decoration: none;
    }
    nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      justify-content: center;
      background-color: white;
      padding: 10px 0;
    }
    nav ul li {
      margin: 0 10px;
    }
    nav ul li a {
      color: #f2f2f2;
      text-decoration: none;
    }
    section {
      padding: 20px;
      text-align: center;
    }
    nav ul li:hover {
      background-color: #f2f2f2; /* Changed the background color on hover */
    }
  </style>
  <!-- Template Main CSS File -->
  <link href="style.css" rel="stylesheet">
</head>
<body>
<header >
    <div >

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="affiche.php">Home</a></li>
          <li class="dropdown"><a href="#"><span>Matiere</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="affiche.php">Afficher Matiere</a></li>
              <li><a href="ajouter.php">Ajouter Matiere</a></li>
              <li><a href="update1.php">Modifier Matiere</a></li>
              <li><a href="filtre.php">recherche Matiere</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>Cellules</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="afficherCell.php">AfficherCell</a></li>
              <li><a href="ajouterCell.php">AjouterCell</a></li>
              <li><a href="modifierCell.php">ModifierCell</a></li>
              <li><a href="recherche.php">rechercherCell</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>JSSold</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="show.php">Afficher</a></li>
              <li><a href="create.php">Ajouter</a></li>
              <li><a href="update.php">Modifier</a></li>
              <li><a href="delete.php">Supprimer</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>ActionMembres</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="index2.php">Afficher Actions</a></li>
              <li><a href="ajouteract.php">Ajouter Actions</a></li>
              <li><a href="modifier.php">Modifier Actions</a></li>
              <li><a href="supprimeract.php">Supprimer Actions</a></li>
            </ul>
          </li>
        </ul>
        
      </nav><!-- .navbar -->

    </div>
</header>
<?php
include("connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $jour = $_POST["jour"];
    $seance = $_POST["seance"];
    $salle = $_POST["salle"];
    $Code_Classe = $_POST["Code_Classe"];
    $code_Prof = $_POST["code_Prof"];
    $code_Matière = $_POST["code_Matière"];
    $Type_Seance = $_POST["Type_Seance"];
    $Groupe = $_POST["Groupe"];
    $Activite = $_POST["Activite"];
    $_Session = $_POST["Session"];

    
    $sql = "UPDATE JSSold SET Jour=?, Seance=?, Salle=?, `Code_Classe`=?, `code_Prof`=?, `code_Matière`=?, `Type_Seance`=?, Groupe=?, Activite=? WHERE Session=?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error: " . $conn->error);
    }

    // Bind the parameters
    $stmt->bind_param("sssssssssi", $jour, $seance, $salle, $Code_Classe, $code_Prof, $code_Matière, $Type_Seance, $Groupe, $Activite, $_Session);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Record updated successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Update Record</title>
</head>
<body>
    <h2>Update Record</h2>

    <form method="post">
        <label for="jour">Jour:</label>
        <input type="text" name="jour" required><br>

        <label for="seance">Séance:</label>
        <input type="text" name="seance" required><br>

        <label for="salle">Salle:</label>
        <input type="text" name="salle" required><br>

        <label for="Code_Classe">Code Classe:</label>
        <input type="text" name="Code_Classe"><br>

        <label for="code_Prof">Code Prof:</label>
        <input type="text" name="code_Prof"><br>

        <label for="code_Matière">Code Matière:</label>
        <input type="text" name="code_Matière"><br>

        <label for="Type_Seance">Type Séance:</label>
        <input type="text" name="Type_Seance"><br>

        <label for="Groupe">Groupe:</label>
        <input type="text" name="Groupe"><br>

        <label for="Activite">Activité:</label>
        <input type="text" name="Activite"><br>

        <label for="Session">Session:</label>
        <input type="number" name="Session" required><br>

        <input type="submit" value="Update">
    </form>
</body>
</html>
