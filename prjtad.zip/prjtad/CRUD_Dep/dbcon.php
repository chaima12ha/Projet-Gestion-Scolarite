<?php

define("HOSTNAME","localhost");
define("USERNAME","dsi2g1");
define("PASSWORD","dsi1g1");
define("DATABASE","gestionscolaire");

$connection =mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE);

if (!$connection){
    die("Conection Failed");
}

?>