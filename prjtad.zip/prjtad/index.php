<head>
  <meta charset="utf-8">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
      line-height: 1.6;
    }
    header {
      background-color: #f2f2f2;
      color: #f2f2f2;
      padding: 15px 0;
      text-align: center;
    }
    header a {
      color: #f2f2f2;
      text-decoration: none;
    }
    nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      justify-content: center;
      background-color: white;
      padding: 10px 0;
    }
    nav ul li {
      margin: 0 10px;
    }
    nav ul li a {
      color: #f2f2f2;
      text-decoration: none;
    }
    section {
      padding: 20px;
      text-align: center;
    }
    nav ul li:hover {
      background-color: #f2f2f2; /* Changed the background color on hover */
    }
  </style>
  <!-- Template Main CSS File -->
  <link href="style.css" rel="stylesheet">
</head>
<body>
<header >
    <div >

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="affiche.php">Home</a></li>
          <li class="dropdown"><a href="#"><span>Matiere</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="affiche.php">Afficher Matiere</a></li>
              <li><a href="ajouter.php">Ajouter Matiere</a></li>
              <li><a href="update1.php">Modifier Matiere</a></li>
              <li><a href="filtre.php">recherche Matiere</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>Cellules</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="afficherCell.php">AfficherCell</a></li>
              <li><a href="ajouterCell.php">AjouterCell</a></li>
              <li><a href="modifierCell.php">ModifierCell</a></li>
              <li><a href="recherche.php">rechercherCell</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>JSSold</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="show.php">Afficher</a></li>
              <li><a href="create.php">Ajouter</a></li>
              <li><a href="update.php">Modifier</a></li>
              <li><a href="delete.php">Supprimer</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>ActionMembres</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="index2.php">Afficher Actions</a></li>
              <li><a href="ajouteract.php">Ajouter Actions</a></li>
              <li><a href="modifier.php">Modifier Actions</a></li>
              <li><a href="supprimeract.php">Supprimer Actions</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>prof</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="CRUD_Prof/CRUD_Prof/Read.php">Afficher prof</a></li>
              <li><a href="CRUD_Prof/CRUD_Prof/Create.html">Ajouter prof</a></li>
              <li><a href="CRUD_Prof/CRUD_Prof/Update.html">Modifier prof</a></li>
              <li><a href="CRUD_Prof/CRUD_Prof/Delete.html">Supprimer prof</a></li>
              <li><a href="CRUD_Prof/CRUD_Prof/SearchDepartment.php">SearchDepartment</a></li>
              <li><a href="CRUD_Prof/CRUD_Prof/SearchDate.html">SearchDate</a></li>

            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>Etudiant</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="etudiant/select.php">Afficher Etudiant</a></li>
              <li><a href="etudiant/add-form.php">Ajouter Etudiant</a></li>
              <li><a href="etudiant/modifier.php">Modifier Etudiant</a></li>
              <li><a href="etudiant/delete.php">Supprimer Etudiant</a></li>
              <li><a href="etudiant/r.php">RechercherEtudiant</a></li>
              <li><a href="TABLE DossierEtud/User/showDocs.php">Afficher Dossier Etudiant</a></li>
              <li><a href="TABLE DossierEtud/User/addDoc.php">Ajouter DossierEtudiant</a></li>
            
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>classe</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="tableclasse/tableClasse/liste.php">Afficher Classe</a></li>
              <li><a href="tableclasse/tableClasse/ajout.php">Ajouter Classe</a></li>
              <li><a href="tableclasse/tableClasse/modifier.php">Modifier Classe</a></li>
              <li><a href="tableclasse/tableClasse/suprimer.php">Supprimer Classe</a></li>
        </ul>
  </ul>
        
      </nav><!-- .navbar -->

    </div>
</header><!-- End Header -->
 <!-- ======= Hero Section ======= -->
 <style>
  .image-container {
  position: relative;
  display: inline-block;
}

.text-over {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-150%,50%);
  background-color: rgba(255, 255, 255, 0.7);
  padding: 10px;
}

.text-over h2 {
  margin: 0;
  color: #000;
}

  </style>
 <section class="image-with-text">
  <div class="image-container">
    <img src="assets/img/team/hero-bg.jpg" alt="Description de l'image">
    <div class="text-over">
      <h2>Welcome</h2>
      <h3>Your content goes here...</h3>
    </div>
  </div>

</section>


</body>

