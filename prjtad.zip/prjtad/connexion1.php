<?php
    $servername='localhost';
    $user = 'dsi2g1';
    $password ='dsi2g1';
    $db='gestionscolaire';
    $conn = mysqli_connect($servername,$user,$password,$db);
    if(!$conn)
    {
     die("connexion failed".mysql_connect_error());
        
    }
      // echo "la connexion a éte bien établie avec base de donneé <br><br>";
    ?>