<?php
include_once("header.php");
include_once("main.php");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $optionName = $_POST["option_name"];
    $departement = $_POST["departement"];
    $optionArab = $_POST["option_arab"];
    $codeOption = $_POST["code_option"];

    // Validate data if necessary

    // Update data in the database
    $pdo = new connect();
    $query = "UPDATE options SET Option_Name = :optionName, Departement = :departement, Option_AraB = :optionArab WHERE Code_Option = :codeOption";
    $pdostmt = $pdo->prepare($query);

    // Bind parameters
    $pdostmt->bindParam(":optionName", $optionName);
    $pdostmt->bindParam(":departement", $departement);
    $pdostmt->bindParam(":optionArab", $optionArab);
    $pdostmt->bindParam(":codeOption", $codeOption);

    // Execute the query
    if ($pdostmt->execute()) {
        echo "Option mise à jour avec succès.";
        // Redirect to the options list page
        header("Location: ListeOptions.php");
        exit();
    } else {
        echo "Erreur lors de la mise à jour de l'option.";
    }
} else {
    // Form not submitted, fetch existing data for modification
    $pdo = new connect();
    $codeOptionToEdit = $_GET["code_option"]; // Assuming you pass the code_option as a parameter in the URL

    // Fetch existing data
    $query = "SELECT * FROM options WHERE Code_Option = :codeOption";
    $pdostmt = $pdo->prepare($query);
    $pdostmt->bindParam(":codeOption", $codeOptionToEdit);
    $pdostmt->execute();
    $existingData = $pdostmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!-- Form HTML to update an option -->
<h1 class="mt-5">Modifier une Option</h1>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label for="option_name">Nom de l'Option:</label>
    <input type="text" name="option_name" value="<?php echo $existingData["Option_Name"]; ?>" required>

    <label for="departement">Département:</label>
    <input type="text" name="departement" value="<?php echo $existingData["Departement"]; ?>">

    <label for="option_arab">Option Arabe:</label>
    <input type="text" name="option_arab" value="<?php echo $existingData["Option_AraB"]; ?>" required>

    <label for="code_option">Code Option:</label>
    <input type="text" name="code_option" value="<?php echo $existingData["Code_Option"]; ?>" readonly>

    <button type="submit" class="btn btn-primary" value="Modifier"> Update </button>
</form>

<?php  /*include_once("footer.php"); */?>
