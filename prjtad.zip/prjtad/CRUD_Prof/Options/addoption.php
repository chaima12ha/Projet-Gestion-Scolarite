<?php
include_once("header.php");
include_once("main.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $optionName = $_POST["option_name"];
    $departement = $_POST["departement"];
    $optionArab = $_POST["option_arab"];
    $codeOption = $_POST["code_option"];

    // Insert data into the database
    $pdo = new connect();
    $query = "INSERT INTO options (Option_Name, Departement, Option_AraB, Code_Option) VALUES (:optionName, :departement, :optionArab, :codeOption)";
    $pdostmt = $pdo->prepare($query);

    // Bind parameters
    $pdostmt->bindParam(":optionName", $optionName);
    $pdostmt->bindParam(":departement", $departement);
    $pdostmt->bindParam(":optionArab", $optionArab);
    $pdostmt->bindParam(":codeOption", $codeOption);

    // Execute the query with error handling
    try {
        if ($pdostmt->execute()) {
            echo "Option ajoutée avec succès.";
        } else {
            echo "Erreur lors de l'ajout de l'option.";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!-- Form HTML to add an option -->
<h1 class="mt-5">Ajouter une Option</h1>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label for="option_name">Nom de l'Option:</label>
    <input type="text" name="option_name" required>

    <label for="departement">Département:</label>
    <input type="text" name="departement">

    <label for="option_arab">Option Arabe:</label>
    <input type="text" name="option_arab" required>

    <label for="code_option">Code Option:</label>
    <input type="text" name="code_option" required>

    <input type="submit" class="btn btn-primary" value="Ajouter">
</form>

<?php  /*include_once("footer.php"); */?>
