<?php 
include_once("connexion.php");
include_once("header.php");
include_once("main.php");
if (!empty($_GET["id"])) {
    $query = "DELETE FROM options WHERE Code_Option = :id";
    $objstmt = $pdo->prepare($query);
    $objstmt->execute(["id" => $_GET["id"]]);
    $objstmt->closeCursor();
    header("Location:ListeOptions.php");
    exit; // Ensure that no further code is executed after the redirect
}
?>
