<?php 

class connect extends PDO{
    const HOST="localhost";
    const DB="gestionscolarite";
    const USER="dsi2g1";
    const PSW="dsi2g1";
   
    //connexion au serveur
    public function __construct(){
    try{
        parent::__construct("mysql:dbname=".self::DB.";host=".self::HOST, self::USER, self::PSW);
        echo "Done";

    } catch (PDOException $e)
    {echo $e->getMessage()." ".$e->getFile()." ".$e->getLine(); 
    }
}
}
?>

<?php /*

$host="localhost";
$user="root";
$password="";
$db="scolarite";
//connexion au serveur
try{
$idcon=new PDO("mysql:host=$host;dbname=$db",$user,$password);
$idcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e)
{echo ("Erreur Connexion:".$e->getMessage()); exit();} */
?>
     

    