<head>
  <meta charset="utf-8">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
      line-height: 1.6;
    }
    header {
      background-color: #f2f2f2;
      color: #f2f2f2;
      padding: 15px 0;
      text-align: center;
    }
    header a {
      color: #f2f2f2;
      text-decoration: none;
    }
    nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      justify-content: center;
      background-color: white;
      padding: 10px 0;
    }
    nav ul li {
      margin: 0 10px;
    }
    nav ul li a {
      color: #f2f2f2;
      text-decoration: none;
    }
    section {
      padding: 20px;
      text-align: center;
    }
    nav ul li:hover {
      background-color: #f2f2f2; /* Changed the background color on hover */
    }
  </style>
  <!-- Template Main CSS File -->
  <link href="style.css" rel="stylesheet">
</head>
<body>
<header >
    <div >

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="affiche.php">Home</a></li>
          <li class="dropdown"><a href="#"><span>Matiere</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="affiche.php">Afficher Matiere</a></li>
              <li><a href="ajouter.php">Ajouter Matiere</a></li>
              <li><a href="update1.php">Modifier Matiere</a></li>
              <li><a href="filtre.php">recherche Matiere</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>Cellules</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="afficherCell.php">AfficherCell</a></li>
              <li><a href="ajouterCell.php">AjouterCell</a></li>
              <li><a href="modifierCell.php">ModifierCell</a></li>
              <li><a href="recherche.php">rechercherCell</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>JSSold</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="show.php">Afficher</a></li>
              <li><a href="create.php">Ajouter</a></li>
              <li><a href="update.php">Modifier</a></li>
              <li><a href="delete.php">Supprimer</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>ActionMembres</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="index2.php">Afficher Actions</a></li>
              <li><a href="ajouteract.php">Ajouter Actions</a></li>
              <li><a href="modifier.php">Modifier Actions</a></li>
              <li><a href="supprimeract.php">Supprimer Actions</a></li>
            </ul>
          </li>
        </ul>
        
      </nav><!-- .navbar -->

    </div>
</header>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JSSold</title>
</head>

<body>
    <div class="container">
        <form method="GET">
            <ul>
                <li><label for="Jour">Filter Jour:</label>
                    <input type="text" id="Jour" name="Jour" placeholder="Enter Jour">
                </li>
                <li><label for="Seance">Filter Seance:</label>
                    <input type="text" id="Seance" name="Seance" placeholder="Enter Seance">
                </li>
                <li><label for="Salle">Filter Salle:</label>
                    <input type="text" id="Salle" name="Salle" placeholder="Enter Salle">
                </li>
                <li><label for="Code_Classe">Filter Code_Classe:</label>
                    <input type="text" id="Code_Classe" name="Code_Classe" placeholder="Enter Code_Classe">
                </li>
                <li><label for="code_prof">Filter code_prof:</label>
                    <input type="text" id="code_prof" name="code_prof" placeholder="Enter code_prof">
                </li>
                <li><label for="code_Matière ">Filter code_matiére:</label>
                    <input type="text" id="code_Matière " name="code_Matière " placeholder="Enter code_Matière ">
                </li>
                <li><label for="Type_Seance">Filter Type_Seance:</label>
                    <input type="text" id="Type_Seance" name="Type_Seance" placeholder="Type_Seance">
                </li>
                <li><label for="Groupe">Filter Groupe:</label>
                    <input type="text" id="Groupe" name="Groupe" placeholder="Enter Group">
                </li>
                <li><label for="Activite">Filter Activite:</label>
                    <input type="text" id="Activite" name="Activite" placeholder="Enter Activite">
                </li>
                <li><label for="Session">Filter Session:</label>
                    <input type="text" id="Session" name="Session" placeholder="Enter Session">
                </li>
                <input type="submit" value="Filter">
            </ul>
        </form>
        <table>
            <tr id="items">
                <th>Jour</th>
                <th>Seance</th>
                <th>Salle</th>
                <th>Code Classe</th>
                <th>code prof</th>
                <th>code Matiére</th>
                <th>Type Seance</th>
                <th>Group</th>
                <th>Activite</th>
                <th>Session</th>

            </tr>
            <?php
            //inclure la page de connexion
            include_once "connection.php";
            // Check if a filter value has been provided in the URL for NumProf
            if (isset($_GET['Jour']) && !empty($_GET['Jour'])) {
                $Jour = $_GET['Jour'];
                $conditions[] = "Jour LIKE '%$Jour%'";
            }

            // Check if a filter value has been provided in the URL for DatePart
            if (isset($_GET['Seance']) && !empty($_GET['Seance'])) {
                $Seance = $_GET['Seance'];
                $conditions[] = "Seance LIKE '%$Seance%'";
            }
            if (isset($_GET['Salle']) && !empty($_GET['Salle'])) {
                $Salle = $_GET['Salle'];
                $conditions[] = "Salle LIKE '%$Salle%'";
            }
            if (isset($_GET['Code_Classe']) && !empty($_GET['Code_Classe'])) {
                $Code_Classe = $_GET['Code_Classe'];
                $conditions[] = "Code_Classe LIKE '%$Code_Classe%'";
            }
            if (isset($_GET['code_prof']) && !empty($_GET['code_prof'])) {
                $code_prof = $_GET['code_prof'];
                $conditions[] = "code_prof LIKE '%$code_prof%'";
            }
            if (
                isset($_GET['code_Matière ']) && !empty($_GET['code_Matière '])
            ) {
                $code_Matière = $_GET['code_Matière '];
                $conditions[] = "code_Matière  LIKE '%$code_Matière %'";
            }
            if (
                isset($_GET['Type_Seance']) && !empty($_GET['Type_Seance'])
            ) {
                $Type_Seance = $_GET['Type_Seance'];
                $conditions[] = "Type_Seance LIKE '%$Type_Seance%'";
            }
            if (isset($_GET['Groupe']) && !empty($_GET['Groupe'])) {
                $Groupe = $_GET['Groupe'];
                $conditions[] = "Groupe LIKE '%$Groupe%'";
            }
            if (isset($_GET['Activite']) && !empty($_GET['Activite'])) {
                $Activite = $_GET['Activite'];
                $conditions[] = "Activite LIKE '%$Activite%'";
            }
            if (isset($_GET['Session']) && !empty($_GET['Session'])) {
                $Session = $_GET['Session'];
                $conditions[] = "Session LIKE '%$Session%'";
            }

            $query = "SELECT * FROM JSSold";
            if (!empty($conditions)) {
                $query .= " WHERE " . implode(" AND ", $conditions);
            }
            $req = mysqli_query($conn, $query);

            // $req = mysqli_query($con, "SELECT * FROM JSSold");
            if (mysqli_num_rows($req) == 0) {

                echo "Il n'y a pas encore d'actionMembres ajouter !";

            } else {

                while ($row = mysqli_fetch_assoc($req)) {
                    ?>
                    <tr>
                        <td>
                            <?= $row['Jour'] ?>
                        </td>
                        <td>
                            <?= $row['Seance'] ?>
                        </td>
                        <td>
                            <?= $row['Salle'] ?>
                        </td>
                        <td>
                            <?= $row['Code_Classe'] ?>
                        </td>
                        <td>
                            <?= $row['code_Prof'] ?>
                        </td>
                        <td>
                            <?= $row['code_Matière'] ?>
                        </td>
                        <td>
                            <?= $row['Type_Seance'] ?>
                        </td>
                        <td>
                            <?= $row['Groupe'] ?>
                        </td>
                        <td>
                            <?= $row['Activite'] ?>
                        </td>
                        <td>
                            <?= $row['Session'] ?>
                        </td>
                    </tr>
                    <?php
                }

            }
            ?>


        </table>




    </div>
</body>

</html>