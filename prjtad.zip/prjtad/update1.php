<head>
  <meta charset="utf-8">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
      line-height: 1.6;
    }
    header {
      background-color: #f2f2f2;
      color: #f2f2f2;
      padding: 15px 0;
      text-align: center;
    }
    header a {
      color: #f2f2f2;
      text-decoration: none;
    }
    nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      justify-content: center;
      background-color: white;
      padding: 10px 0;
    }
    nav ul li {
      margin: 0 10px;
    }
    nav ul li a {
      color: #f2f2f2;
      text-decoration: none;
    }
    section {
      padding: 20px;
      text-align: center;
    }
    nav ul li:hover {
      background-color: #f2f2f2; /* Changed the background color on hover */
    }
    .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
        h1 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #008080;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:nth-child(odd) {
            background-color: #fff;
        }
        .search-form {
            margin-top: 20px;
        }
        .search-label {
            font-weight: bold;
        }
        .search-input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .search-button {
            background-color: #007BFF;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            font-size: 18px;
            cursor: pointer;
        }
        
        input[type="submit"] {
            background-color: #008080;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            font-size: 18px;
            cursor: pointer;
        }
  </style>
  <!-- Template Main CSS File -->
  <link href="style.css" rel="stylesheet">
</head>
<body>
<header >
    <div >

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="affiche.php">Home</a></li>
          <li class="dropdown"><a href="#"><span>Matiere</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="affiche.php">Afficher Matiere</a></li>
              <li><a href="ajouter.php">Ajouter Matiere</a></li>
              <li><a href="update1.php">Modifier Matiere</a></li>
              <li><a href="filtre.php">recherche Matiere</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>Cellules</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="afficherCell.php">AfficherCell</a></li>
              <li><a href="ajouterCell.php">AjouterCell</a></li>
              <li><a href="modifierCell.php">ModifierCell</a></li>
              <li><a href="recherche.php">rechercherCell</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>JSSold</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="show.php">Afficher</a></li>
              <li><a href="create.php">Ajouter</a></li>
              <li><a href="update.php">Modifier</a></li>
              <li><a href="delete.php">Supprimer</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>ActionMembres</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="index2.php">Afficher Actions</a></li>
              <li><a href="ajouteract.php">Ajouter Actions</a></li>
              <li><a href="modifier.php">Modifier Actions</a></li>
              <li><a href="supprimeract.php">Supprimer Actions</a></li>
            </ul>
          </li>
        </ul>
        
      </nav><!-- .navbar -->

    </div>
</header>
<head>
<link rel="stylesheet"  href="style.css">
</head>

<?php
include_once "connexion1.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $id = $_POST['id'];
    $sql = "SELECT * FROM Matiere WHERE Code_Matiere = '$id'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        
        $codeMatiere = $row['Code_Matiere'];
        $sess = $row['Sess'];
        $nomMatiere = $row['Nom_Matiere'];
        $coefMatiere = $row['Coef_Matiere'];
        $departement = $row['Departement'];
        $semestre = $row['Semestre'];
        $option = $row['Option'];
        $nbHeureCI = $row['Nb_Heure_CI'];
        $nbHeureTP = $row['Nb_Heure_TP'];
        $typeLabo = $row['TypeLabo'];
        $bonus = $row['Bonus'];
        $categories = $row['Categories'];
        $sousCategories = $row['SousCategories'];
        $dateDebut = $row['DateDeb'];
        $dateFin = $row['DateFin'];
        $session = $row['session'];
        $responsable = $row['Responsable'];
        $c = $row['C'];
        $td = $row['TD'];

        echo "<div class='container'>
        <form action='up.php' method='post'>
                <input type='hidden' name='id' value='$codeMatiere'>
                Code Matière: <input type='text' name='codeMatiere' value='$codeMatiere'><br>
                Session: <input type='text' name='sess' value='$sess'><br>
                Nom Matière: <input type='text' name='nomMatiere' value='$nomMatiere'><br>
                Coefficient Matière: <input type='text' name='coefMatiere' value='$coefMatiere'><br>
                Département: <input type='text' name='departement' value='$departement'><br>
                Semestre: <input type='text' name='semestre' value='$semestre'><br>
                Option: <input type='text' name='option' value='$option'><br>
                Nombre d'Heures CI: <input type='text' name='nbHeureCI' value='$nbHeureCI'><br>
                Nombre d'Heures TP: <input type='text' name='nbHeureTP' value='$nbHeureTP'><br>
                Type de Laboratoire: <input type='text' name='typeLabo' value='$typeLabo'><br>
                Bonus: <input type='text' name='bonus' value='$bonus'><br>
                Catégories: <input type='text' name='categories' value='$categories'><br>
                Sous-Catégories: <input type='text' name='sousCategories' value='$sousCategories'><br>
                Date de Début: <input type='text' name='dateDebut' value='$dateDebut'><br>
                Date de Fin: <input type='text' name='dateFin' value='$dateFin'><br>
                Session: <input type='text' name='session' value='$session'><br>
                Responsable: <input type='text' name='responsable' value='$responsable'><br>
                C: <input type='text' name='c' value='$c'><br>
                TD: <input type='text' name='td' value='$td'><br>
               
                <input type='submit' value='Enregistrer les modifications'>
            </form>
            </div>"
            ;
    } else {
        echo "Erreur : Données non trouvées.";
    }

    mysqli_free_result($result);
} else {
    $sql = "SELECT * FROM Matiere";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        echo "
        <table border='1'>
                <tr>
                    <th>Code Matière</th>
                    <th>Session</th>
                    <th>Nom Matière</th>
                    <th>Coefficient Matière</th>
                    <th>Département</th>
                    <th>Semestre</th>
                    <th>Option</th>
                    <th>Nombre d'Heures CI</th>
                    <th>Nombre d'Heures TP</th>
                    <th>Type de Laboratoire</th>
                    <th>Bonus</th>
                    <th>Catégories</th>
                    <th>Sous-Catégories</th>
                    <th>Date de Début</th>
                    <th>Date de Fin</th>
                    <th>Session</th>
                    <th>Responsable</th>
                    <th>C</th>
                    <th>TD</th>
                    <th>Actions</th>
                </tr>";

        while($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['Code_Matiere']}</td>
                    <td>{$row['Sess']}</td>
                    <td>{$row['Nom_Matiere']}</td>
                    <td>{$row['Coef_Matiere']}</td>
                    <td>{$row['Departement']}</td>
                    <td>{$row['Semestre']}</td>
                    <td>{$row['Option']}</td>
                    <td>{$row['Nb_Heure_CI']}</td>
                    <td>{$row['Nb_Heure_TP']}</td>
                    <td>{$row['TypeLabo']}</td>
                    <td>{$row['Bonus']}</td>
                    <td>{$row['Categories']}</td>
                    <td>{$row['SousCategories']}</td>
                    <td>{$row['DateDeb']}</td>
                    <td>{$row['DateFin']}</td>
                    <td>{$row['session']}</td>
                    <td>{$row['Responsable']}</td>
                    <td>{$row['C']}</td>
                    <td>{$row['TD']}</td>
                    <td>
                        <form action='' method='post'>
                            <input type='hidden' name='id' value='{$row['Code_Matiere']}'>
                            <input type='submit' value='Modifier'>
                        </form>

                        <form action='supprime.php' method='post' onsubmit ='return confirm(\"Etes sur de supprimer cet Matiere???\")'>
                        <input type='hidden' name='id' value='{$row['Code_Matiere']}'>
                        <input type='submit' value='Supprimer'>
                    

                    </form>
                      
                    </td>
                </tr>";
        }

        echo "</table>";
    } else {
        echo "<br>Aucune donnée trouvée.";
    }
}

mysqli_close($conn);
?>