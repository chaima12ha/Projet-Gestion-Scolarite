<head>
  <meta charset="utf-8">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
      line-height: 1.6;
    }
    header {
      background-color: #f2f2f2;
      color: #f2f2f2;
      padding: 15px 0;
      text-align: center;
    }
    header a {
      color: #f2f2f2;
      text-decoration: none;
    }
    nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      justify-content: center;
      background-color: white;
      padding: 10px 0;
    }
    nav ul li {
      margin: 0 10px;
    }
    nav ul li a {
      color: #f2f2f2;
      text-decoration: none;
    }
    section {
      padding: 20px;
      text-align: center;
    }
    nav ul li:hover {
      background-color: #f2f2f2; /* Changed the background color on hover */
    }
    .container {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
        h1 {
            text-align: center;
        }
        form {
            text-align: left;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            font-size: 16px;
        }
        button[type="submit"] {
            background-color: #008080;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            font-size: 18px;
            cursor: pointer;
        }
        button[type="reset"] {
            background-color: #ccc;
            color: #000;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            font-size: 18px;
            cursor: pointer;
        }
        input[type="submit"] {
            background-color: #008080;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            font-size: 18px;
            cursor: pointer;
        }
  </style>
  <!-- Template Main CSS File -->
  <link href="style.css" rel="stylesheet">
</head>
<body>
<header >
    <div >

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="affiche.php">Home</a></li>
          <li class="dropdown"><a href="#"><span>Matiere</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="affiche.php">Afficher Matiere</a></li>
              <li><a href="ajouter.php">Ajouter Matiere</a></li>
              <li><a href="update1.php">Modifier Matiere</a></li>
              <li><a href="filtre.php">recherche Matiere</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>Cellules</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="afficherCell.php">AfficherCell</a></li>
              <li><a href="ajouterCell.php">AjouterCell</a></li>
              <li><a href="modifierCell.php">ModifierCell</a></li>
              <li><a href="recherche.php">rechercherCell</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>JSSold</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="show.php">Afficher</a></li>
              <li><a href="create.php">Ajouter</a></li>
              <li><a href="update.php">Modifier</a></li>
              <li><a href="delete.php">Supprimer</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>ActionMembres</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="index2.php">Afficher Actions</a></li>
              <li><a href="ajouteract.php">Ajouter Actions</a></li>
              <li><a href="modifier.php">Modifier Actions</a></li>
              <li><a href="supprimeract.php">Supprimer Actions</a></li>
            </ul>
          </li>
        </ul>
        
      </nav><!-- .navbar -->

    </div>
</header>
<?php
// ini_set("display_errors", "1");
// error_reporting(E_ALL);
include "connexion1.php";
if(isset($_POST['Ajouter'])){
    $Code_Matiere = $_POST['Code_Matiere'];
    $Sess = $_POST['Sess'];
    $Nom_Matiere= $_POST['Nom_Matiere'];
    $Coef_Matiere=$_POST['Coef_Matiere'];
    $Departement= $_POST['Departement'];
    $Semestre=$_POST['Semestre'];
    $Option=$_POST['Option'];
    $Nb_Heure_CI=$_POST['Nb_Heure_CI'];
    $Nb_Heure_TP= $_POST['Nb_Heure_TP'];
    $TypeLabo= $_POST['TypeLabo'];
    $Bonus= $_POST['Bonus'];
    $Categories= $_POST['Categories'];
    $SousCategories= $_POST['SousCategories'];
    $DateDeb= $_POST['DateDeb'];
    $DateFin= $_POST['DateFin'];
    $session= $_POST['session'];
    $Responsable= $_POST['Responsable'];
    $C= $_POST['C'];
    $TD= $_POST['TD'];
    $check="SELECT * FROM Matiere WHERE Code_Matiere='$Code_Matiere'";
    $Check_res=mysqli_query($conn,$check);
    if(mysqli_num_rows($Check_res)>0)
    {
        echo '<script>alert("la code de matiere existe deja dans la BD");</script>';
        // $error_message="la matiere avec le code '$Code_Matiere' existe deja dans la BD";

    }else{
        $sql = "INSERT INTO `Matiere` (`Code_Matiere`, `Sess`, `Nom_Matiere`, `Coef_Matiere`, `Departement`, `Semestre`, `Option`, `Nb_Heure_CI`, `Nb_Heure_TP`, `TypeLabo`, `Bonus`, `Categories`, `SousCategories`, `DateDeb`, `DateFin`, `session`, `Responsable`, `C`, `TD`) 
            VALUES ('$Code_Matiere', '$Sess', '$Nom_Matiere', '$Coef_Matiere', '$Departement', '$Semestre', '$Option', '$Nb_Heure_CI', '$Nb_Heure_TP', '$TypeLabo', '$Bonus', '$Categories', '$SousCategories', '$DateDeb', '$DateFin', '$session', '$Responsable', '$C', '$TD')";
        $result = mysqli_query($conn, $sql);
    if ($result) {
        echo '<script>alert("Matière ajoutée avec succès !");</script>';
        // $success_message = "Matière ajoutée avec succès !";
    } else {
        echo '<script>alert("Erreur lors d ajout de la matière :");</script>';
        // $error_message = "Erreur lors de l'ajout de la matière : " . mysqli_error($conn);
    }
    }}
    mysqli_close($conn);
?>
<!-- <1?php if(isset($success_message)): ?>
    <div style="color: green;"><1?php echo $success_message; ?></div>
<1?php endif; ?>
<1?php if(isset($error_message)): ?>
    <div style="color: red;"><1?php echo $error_message; ?></div>
<1?php endif; ?> -->
<!DOCTYPE html>
<html>
<head>
    <title>Formulaire Matière</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<h2>Ajouter une Matière</h2>
<div class="container">
<form  method="POST">

    <label for="Code_Matiere">Code Matière:</label>
    <input type="text" id="Code_Matiere" name="Code_Matiere"  required><br>

    <label for="Sess">Session:</label>
    <input type="number" id="Sess" name="Sess" required><br>

    <label for="Nom_Matiere">Nom Matière:</label>
    <input type="text" id="Nom_Matiere" name="Nom_Matiere" required><br>

    <label for="Coef_Matiere">Coefficient Matière:</label>
    <input type="number" id="Coef_Matiere" name="Coef_Matiere" required><br>

    <label for="Departement">Département:</label>
    <input type="text" id="Departement" name="Departement" required><br>

    <label for="Semestre">Semestre:</label>
    <input type="text" id="Semestre" name="Semestre" required><br>

    <label for="Option">Option:</label>
    <input type="text" id="Option" name="Option" required><br>

    <label for="Nb_Heure_CI">Nombre d'Heures CI:</label>
    <input type="number"  id="Nb_Heure_CI" name="Nb_Heure_CI" required><br>

    <label for="Nb_Heure_TP">Nombre d'Heures TP:</label>
    <input type="number"id="Nb_Heure_TP" name="Nb_Heure_TP" required><br>

    <label for="TypeLabo">Type de Laboratoire:</label>
    <input type="text" id="TypeLabo" name="TypeLabo" required><br>

    <label for="Bonus">Bonus:</label>
    <input type="number" id="Bonus" name="Bonus" required><br>

    <label for="Categories">Catégories:</label>
    <input type="text" id="Categories" name="Categories" required><br>

    <label for="SousCategories">Sous-Catégories:</label>
    <input type="text" id="SousCategories" name="SousCategories" required><br>

    <label for="DateDeb">Date de Début:</label>
    <input type="datetime-local" id="DateDeb" name="DateDeb" required><br>

    <label for="DateFin">Date de Fin:</label>
    <input type="datetime-local" id="DateFin" name="DateFin" required><br>

    <label for="session">Session:</label>
    <input type="number" id="session" name="session" required><br>

    <label for="Responsable">Responsable:</label>
    <input type="number" id="Responsable" name="Responsable" required><br>

    <label for="C">C:</label>
    <input type="number"  id="C" name="C" required><br>

    <label for="TD">TD:</label>
    <input type="number" id="TD" name="TD" required><br>

    <button type="submit" name="Ajouter">Ajouter</button>


</form>

<form action='update.php' method='post'>
    <input type="submit" value="Modifier">
</form>
<form action='filtre.php' method='post'>
    <input type="submit" value="filtre">
</form>
</div>
</body>
</html>



 