<?php
$host="localhost";
$user="dsi2g1";
$password="dsi2g1";
$db="gestionscolaire";
$dsn="mysql:host=$host;dbname=$db";
try{

    $idcom= new PDO($dsn, $user, $password);
    $idcom->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}


catch (PDOException $e) {
    
    echo ('Erreur : ' . $e->getMessage());

    exit();
    }
?>