<?php

require "connexion.php";


$codeclasse = $_GET['Cod'];
$req = "DELETE FROM `Classe` WHERE CodClasse='$codeclasse'";

$idcom->exec($req);

header('location: liste.php');
