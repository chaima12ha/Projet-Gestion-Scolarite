<head>
  <meta charset="utf-8">

  <!-- Template Main CSS File -->
  <link href="style.css" rel="stylesheet">
</head>
<body>
<style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
      line-height: 1.6;
    }
    header {
      background-color: #f2f2f2;
      color: #f2f2f2;
      padding: 15px 0;
      text-align: center;
    }
    header a {
      color: #f2f2f2;
      text-decoration: none;
    }
    nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      justify-content: center;
      background-color: white;
      padding: 10px 0;
    }
    nav ul li {
      margin: 0 10px;
    }
    nav ul li a {
      color: #f2f2f2;
      text-decoration: none;
    }
    section {
      padding: 20px;
      text-align: center;
    }
    nav ul li:hover {
      background-color: #f2f2f2; /* Changed the background color on hover */
    }
  </style>
<header >
    <div >

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="affiche.php">Home</a></li>
          <li class="dropdown"><a href="#"><span>Matiere</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="affiche.php">Afficher Matiere</a></li>
              <li><a href="ajouter.php">Ajouter Matiere</a></li>
              <li><a href="update1.php">Modifier Matiere</a></li>
              <li><a href="filtre.php">recherche Matiere</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>Cellules</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="afficherCell.php">AfficherCell</a></li>
              <li><a href="ajouterCell.php">AjouterCell</a></li>
              <li><a href="modifierCell.php">ModifierCell</a></li>
              <li><a href="recherche.php">rechercherCell</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>JSSold</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="show.php">Afficher</a></li>
              <li><a href="create.php">Ajouter</a></li>
              <li><a href="update.php">Modifier</a></li>
              <li><a href="delete.php">Supprimer</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>ActionMembres</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="index2.php">Afficher Actions</a></li>
              <li><a href="ajouteract.php">Ajouter Actions</a></li>
              <li><a href="modifier.php">Modifier Actions</a></li>
              <li><a href="supprimeract.php">Supprimer Actions</a></li>
            </ul>
          </li>
        </ul>
        
      </nav><!-- .navbar -->

    </div>
</header>
<?php
include_once "connexion1.php"; 
$sql ="SELECT * from Matiere";
$result = $conn->query($sql);

    if($result->num_rows > 0) {
        echo "<h1 >Liste Des Matieres</h1>
        <table border='1'>
        <tr>
        <th> code matiere</th>
        <th> Session</th>
        <th>  nom matiere</th>
        <th> coef matiere</th>
        <th> departement</th>
        <th> semestre</th>
        <th> option</th>
        <th> HR CI</th>
        <th> HR TP</th>
        <th> Bonus</th>
        <th> categories</th>
        <th> sous categorie</th>
        <th> date deb</th>
        <th> date fin</th>
        <th> responsable</th>
        <th> c</th>
        <th> td</th>
        </tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['Code_Matiere'] . "</td>";
            echo "<td>" . $row['Sess'] . "</td>";
            echo "<td>" . $row['Nom_Matiere'] . "</td>";
            echo "<td>" . $row['Coef_Matiere'] . "</td>";
            echo "<td>" . $row['Departement'] . "</td>";
            echo "<td>" . $row['Semestre'] . "</td>";
            echo "<td>" . $row['Option'] . "</td>";
            echo "<td>" . $row['Nb_Heure_CI'] . "</td>";
            echo "<td>" . $row['Nb_Heure_TP'] . "</td>";
            echo "<td>" . $row['Bonus'] . "</td>";
            echo "<td>" . $row['Categories'] . "</td>";
            echo "<td>" . $row['SousCategories'] . "</td>";
            echo "<td>" . $row['DateDeb'] . "</td>";
            echo "<td>" . $row['DateFin'] . "</td>";
            echo "<td>" . $row['Responsable'] . "</td>";
            echo "<td>" . $row['C'] . "</td>";
            echo "<td>" . $row['TD'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "Aucun résultat trouvé.";
    }
$conn->close();
?>
