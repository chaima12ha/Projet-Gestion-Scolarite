<?php
$host = "localhost";
$username = "dsi2g1";
$password = "dsi2g1";
$database = "gestionscolaire";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
