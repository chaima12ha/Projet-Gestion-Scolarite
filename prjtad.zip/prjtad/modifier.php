<head>
  <meta charset="utf-8">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
      line-height: 1.6;
    }
    header {
      background-color: #f2f2f2;
      color: #f2f2f2;
      padding: 15px 0;
      text-align: center;
    }
    header a {
      color: #f2f2f2;
      text-decoration: none;
    }
    nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      justify-content: center;
      background-color: white;
      padding: 10px 0;
    }
    nav ul li {
      margin: 0 10px;
    }
    nav ul li a {
      color: #f2f2f2;
      text-decoration: none;
    }
    section {
      padding: 20px;
      text-align: center;
    }
    nav ul li:hover {
      background-color: #f2f2f2; /* Changed the background color on hover */
    }
  </style>
  <!-- Template Main CSS File -->
  <link href="style.css" rel="stylesheet">
</head>
<body>
<header >
    <div >

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="affiche.php">Home</a></li>
          <li class="dropdown"><a href="#"><span>Matiere</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="affiche.php">Afficher Matiere</a></li>
              <li><a href="ajouter.php">Ajouter Matiere</a></li>
              <li><a href="update1.php">Modifier Matiere</a></li>
              <li><a href="filtre.php">recherche Matiere</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>Cellules</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="afficherCell.php">AfficherCell</a></li>
              <li><a href="ajouterCell.php">AjouterCell</a></li>
              <li><a href="modifierCell.php">ModifierCell</a></li>
              <li><a href="recherche.php">rechercherCell</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>JSSold</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="show.php">Afficher</a></li>
              <li><a href="create.php">Ajouter</a></li>
              <li><a href="update.php">Modifier</a></li>
              <li><a href="delete.php">Supprimer</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>ActionMembres</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="index2.php">Afficher Actions</a></li>
              <li><a href="ajouteract.php">Ajouter Actions</a></li>
              <li><a href="modifier.php">Modifier Actions</a></li>
              <li><a href="supprimeract.php">Supprimer Actions</a></li>
            </ul>
          </li>
        </ul>
        
      </nav><!-- .navbar -->

    </div>
</header>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<!-- <!?php

         //connexion à la base de donnée
          include_once "connexion.php";
         //on récupère le id dans le lien
          $NumAction = $_GET['NumAction'];
          //requête pour afficher les infos d'un employé
          $req = mysqli_query($con , "SELECT * FROM ActionMembres WHERE NumAction = $NumAction");
          $row = mysqli_fetch_assoc($req);


       //vérifier que le bouton ajouter a bien été cliqué
       if(isset($_POST['button'])){
           //extraction des informations envoyé dans des variables par la methode POST
           extract($_POST);
           //verifier que tous les champs ont été remplis
           if(isset($NumAction) && isset($NumProf)  && isset($DatePart)  && isset(Qualité)  && isset($Dpt)  && isset($Opt)  && isset($Niveau)  && isset($CodeMat)   && $Remarque){
               //requête de modification
               $req = mysqli_query($con, "UPDATE ActionMembers SET NumAction = '$NumAction' , DatePart = '$DatePart' , Qualité = '$Qualité' , Dpt = '$Dpt' , Opt = '$Opt'  , Niveu = '$Niveau' , CodeMat = '$CodeMat' , Remarque = '$Remarque'  WHERE NumAction = $NumAction");
                if($req){//si la requête a été effectuée avec succès , on fait une redirection
                    header("location: index.php");
                }else {//si non
                    $message = "ActionMmebre non modifié";
                }

           }else {
               //si non
               $message = "Veuillez remplir tous les champs !";
           }
       }
    
    ?> -->
<?php
include_once "connexion.php"; // Ensure your connection file is included

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you have an ID to identify the record to be modified (replace 'id_column' with the actual column name)
    $id = $_POST['id']; // Adjust this according to your form field

    // Prepare the UPDATE statement
    $stmt = $idcon->prepare("UPDATE actionmember 
                             SET NumAction = ?, NumProf = ?, DatePart = ?, Qualité = ?, Dpt = ?, Opt = ?, Niveau = ?, CodeMat = ?, Remarque = ? 
                             WHERE id_column = ?"); // Replace 'id_column' with the actual column name

    // Bind parameters
    $stmt->bindParam(1, $_POST['NumAction'], PDO::PARAM_INT);
    $stmt->bindParam(2, $_POST['NumProf'], PDO::PARAM_INT);
    $stmt->bindParam(3, $_POST['DatePart'], PDO::PARAM_STR);
    $stmt->bindParam(4, $_POST['Qualité'], PDO::PARAM_STR);
    $stmt->bindParam(5, $_POST['Dpt'], PDO::PARAM_STR);
    $stmt->bindParam(6, $_POST['Opt'], PDO::PARAM_STR);
    $stmt->bindParam(7, $_POST['Niveau'], PDO::PARAM_STR);
    $stmt->bindParam(8, $_POST['CodeMat'], PDO::PARAM_STR);
    $stmt->bindParam(9, $_POST['Remarque'], PDO::PARAM_STR);
    $stmt->bindParam(10, $id, PDO::PARAM_INT); // Binding ID parameter

    // Execute the update
    if ($stmt->execute()) {
        header("Location: index.php"); // Redirect on successful update
        exit();
    } else {
        $message = "Erreur lors de la modification";
    }
}
?>
<!-- Rest of your HTML form -->

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Your head content here -->
</head>
<body>
    <!-- Your HTML content for the form -->
    <form method="POST" action="">
        <!-- Include your form fields and any necessary hidden inputs for the record ID -->
    </form>
</body>
</html>

    <div class="form">
        <a href="index.php" class="back_btn"><img src="images/back.png"> Retour</a>
        <h2>Modifier l'action membre : <?=$row['NumAction']?> </h2>
        <p class="erreur_message">
           <?php 
              if(isset($message)){
                  echo $message ;
              }
           ?>
        </p>
        <form action="" method="POST">
            <label>NumAction</label>
            <input type="number" name="NumAction" value="<?=$row['NumAction']?>">
            <label>NumProf</label>
            <input type="number" name="NumProf" value="<?=$row['NumProf']?>">
            <label>DatePart</label>
            <input type="date" name="DatePart" value="<?=$row['DatePart']?>">
            <label>Qualité</label>
            <input type="text" name="Qualité" value="<?=$row['Qualité']?>">
            <label>Dpt</label>
            <input type="text" name="Dpt" value="<?=$row['Dpt']?>">
            <label>Opt</label>
            <input type="text" name="Opt" value="<?=$row['Opt']?>">
            <label>CodeMat</label>
            <input type="text" name="CodeMat" value="<?=$row['CodeMat']?>">
            <label>Remarque</label>
            <input type="text" name="Remarque" value="<?=$row['Remarque']?>">
            <input type="submit" value="Modifier" name="button">
        </form>
    </div>
</body>
</html>